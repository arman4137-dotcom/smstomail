# 🚀 راهنمای کامل ساخت APK نهایی

## ⚠️ نیازمندی ها

برای ساخت APK باید این ها نصب باشند:

```
✓ Java Development Kit (JDK) 11 یا بالاتر
✓ Android Studio (آخرین نسخه)
✓ Android SDK 34
```

---

## 📱 روش 1: ساخت از طریق Android Studio (بهترین)

### مرحله 1: نصب Android Studio

1. به https://developer.android.com/studio بروید
2. نسخه Windows را دانلود کنید
3. فایل را اجرا کرده و نصب کنید
4. تمام پیشنهادها را قبول کنید
5. تا ختم نصب منتظر بمانید (15-20 دقیقه)

### مرحله 2: باز کردن پروژه

```
1. Android Studio را باز کنید
2. Welcome صفحه میں File → Open کلیک کنید
3. به این مسیر بروید:
   C:\Users\[YourName]\OneDrive\Desktop\claude code test domain\smstomail
4. پوشه smstomail را انتخاب کنید
5. OK کلیک کنید
```

### مرحله 3: صبر برای Gradle Sync

```
Android Studio خودکار Gradle Sync را شروع می کند
منتظر بمانید تا مانند این نمایش شود:
   "Gradle: Sync completed successfully"
```

### مرحله 4: ساخت APK

```
1. Build منو را کلیک کنید
2. "Build Bundle(s) / APK(s)" را انتخاب کنید
3. "Build APK(s)" را کلیک کنید
4. منتظر بمانید (2-5 دقیقه)
```

### مرحله 5: موفقیت!

```
پایان پنجره میں این پیام را ببینید:
   "Build successfully finished"

APK فایل اینجا ایجاد می شود:
   app/build/outputs/apk/debug/app-debug.apk
```

---

## 💻 روش 2: ساخت از طریق Command Line

### پیش نیاز:

```bash
# بررسی Java
java -version
# باید نسخه 11 یا بالاتر باشد

# بررسی ANDROID_HOME
echo %ANDROID_HOME%
# باید اینجا نشان دهد: C:\Users\[YourName]\AppData\Local\Android\Sdk
```

### اگر ANDROID_HOME تنظیم نشده:

```bash
# برای این session:
set ANDROID_HOME=C:\Users\[YourName]\AppData\Local\Android\Sdk

# برای همیشه (Windows 10/11):
# تنظیمات → Variables محیطی → New:
#   Variable: ANDROID_HOME
#   Value: C:\Users\[YourName]\AppData\Local\Android\Sdk
```

### ساخت APK

```bash
# به پروژه بروید
cd "C:\Users\[YourName]\OneDrive\Desktop\claude code test domain\smstomail"

# APK Debug را بسازید
gradlew.bat assembleDebug

# یا Release:
gradlew.bat assembleRelease
```

### منتظر بمانید

```
عملیات 5-10 دقیقه طول می کشد

شاید این پیام ها ببینید:
  Downloading gradle-8.4-all.zip
  Downloading dependencies
  Compiling resources
  Building APK
  
تمام شده:
  BUILD SUCCESSFUL
  app-debug.apk created
```

---

## 📍 مکان فایل های APK

### Debug APK (برای تست و نصب شخصی):
```
app/build/outputs/apk/debug/app-debug.apk
اندازه: ~35 MB
```

### Release APK (اختیاری - برای نهایی):
```
app/build/outputs/apk/release/app-release.apk
اندازه: ~15 MB

(برای Release نیاز به signing است)
```

---

## 🎯 بعد از ساخت APK

### نصب روی گوشی:

#### روش 1: اتصال مستقیم

```bash
# فایل APK را پیدا کنید
app-debug.apk

# نصب کنید
adb install app-debug.apk
```

#### روش 2: منتقل کردن فایل

```
1. فایل app-debug.apk را کپی کنید
2. به گوشی منتقل کنید (USB یا Telegram)
3. روی گوشی: فایل را کلیک کنید
4. [نصب] را کلیک کنید
```

---

## ✅ مراحل چک لیست

```
نصب و تنظیم:
  [ ] Java نصب شده (java -version)
  [ ] Android Studio نصب شده
  [ ] SDK 34 دانلود شده
  [ ] ANDROID_HOME تنظیم شده

ساخت:
  [ ] پروژه در Android Studio باز شد
  [ ] Gradle Sync موفق شد
  [ ] Build APK شروع شد
  [ ] Build موفق شد

نصب:
  [ ] APK دانلود شده
  [ ] گوشی Debug Mode روشن است
  [ ] APK نصب شده
  [ ] اپلیکیشن کار می کند
```

---

## 🔍 حل مشکلات

### مشکل: "Gradle sync failed"

```
راه حل:
1. File → Invalidate Caches / Restart
2. Clear Cache and Restart را کلیک کنید
3. منتظر بمانید تا دوباره load شود
4. دوباره سعی کنید
```

### مشکل: "Java version not found"

```
راه حل:
1. Java نصب نشده است
2. Java SE Development Kit دانلود کنید:
   https://www.oracle.com/java/technologies/downloads/
3. نسخه 11 یا بالاتر را نصب کنید
4. Android Studio را restart کنید
```

### مشکل: "Android SDK not found"

```
راه حل:
1. Android Studio را باز کنید
2. File → Project Structure → SDK Location
3. Android SDK Location را چک کنید
4. اگر خالی است، Android SDK Location را انتخاب کنید
5. SDK Manager منو دارید
6. Platform 34 را نصب کنید
```

### مشکل: Build fail شد

```
راه حل:
1. اطمینان حاصل کنید همه dependencies دانلود شدند
2. gradle.properties را چک کنید
3. build.gradle dependencies را بررسی کنید
4. Clean و Rebuild کنید:
   Build → Clean Project
   Build → Build APK(s)
```

---

## 📊 زمان صرف شده

```
نصب Android Studio:        15-20 دقیقه
Gradle Sync:               3-5 دقیقه
ساخت APK (اول):           5-10 دقیقه
ساخت APK (بار دوم):       2-3 دقیقه
نصب بر روی گوشی:          1 دقیقه
کل:                        26-39 دقیقه
```

---

## 🎉 نتیجه نهایی

بعد از انجام این مراحل:

```
✓ APK نهایی ایجاد شد
✓ روی گوشی نصب شد
✓ اپلیکیشن آماده است
✓ تنظیمات ایمیل را انجام دهید:
  - arman4137@gmail.com
  - armansafayi.com@gmail.com
✓ App Password برای Gmail دریافت کنید
✓ اپلیکیشن را فعال کنید
```

---

## 📚 منابع مفید

🔗 Java Download: https://www.oracle.com/java/technologies/downloads/  
🔗 Android Studio: https://developer.android.com/studio  
🔗 Android SDK: https://developer.android.com/studio#downloads  
🔗 Gmail App Password: https://support.google.com/accounts/answer/185833  

---

## 💡 نکات اضافی

**برای Release Build (نهایی):**
```bash
gradlew.bat assembleRelease
```

**برای دیباگ:**
```bash
gradlew.bat assembleDebug --stacktrace
```

**برای پاک کردن:**
```bash
gradlew.bat clean
```

**برای اطلاعات بیشتر:**
```bash
gradlew.bat tasks
```

---

**حالا شروع کنید! موفق باشید!** 🚀✨
