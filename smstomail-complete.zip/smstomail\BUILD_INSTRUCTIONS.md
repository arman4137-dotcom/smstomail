# راهنمای ساخت فایل APK

این فایل راهنمای کامل ساخت فایل APK قابل نصب است.

## الف: نیازمندی ها

### 1. دانلود Android Studio

- به سایت [developer.android.com/studio](https://developer.android.com/studio) بروید
- نسخه آخر Android Studio را دانلود کنید
- فایل را اجرا کنید و نصب کنید

### 2. هنگام نصب Android Studio

اطمینان حاصل کنید که:
- [ ] Android SDK 34 را نصب کنید
- [ ] Kotlin plugin را نصب کنید
- [ ] Java Development Kit 11+ را نصب کنید

### 3. متغیرهای محیط (برای استفاده از Terminal)

اگر می خواهید از Command Line استفاده کنید:

**برای Windows:**
```
ANDROID_HOME = C:\Users\[YourUsername]\AppData\Local\Android\Sdk
```

**برای Mac/Linux:**
```
export ANDROID_HOME=$HOME/Library/Android/Sdk
```

## ب: باز کردن پروژه

### مرحله 1: دانلود فایل ها

تمام فایل های اپلیکیشن در پوشه `smstomail` قرار دارند.

### مرحله 2: باز کردن Android Studio

```
File → Open → سمت چپ پوشه "smstomail" را انتخاب کنید
```

### مرحله 3: صبر کنید

Gradle synchronized شود. این ممکن است 2-5 دقیقه طول بکشد.

## ج: ساخت APK

### روش 1: GUI (بدون Terminal)

**مرحله 1:** در Android Studio

```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

**مرحله 2:** صبر کنید

عملیات ساخت 2-3 دقیقه طول می کشد.

**مرحله 3:** پیام موفقیت

```
Build successfully finished
```

**مرحله 4:** مکان فایل

```
app\build\outputs\apk\debug\app-debug.apk
```

### روش 2: Terminal/Command Line

```bash
./gradlew assembleDebug
```

یا در Windows:

```cmd
gradlew.bat assembleDebug
```

## د: نصب بر روی گوشی

### پیش نیاز: Debug Mode

1. تنظیمات گوشی → درباره گوشی
2. 7 بار روی "نسخه نرم افزار" کلیک کنید
3. تنظیمات → گزینه های توسعه دهنده → Debug USB را ON کنید

### نصب روش 1: اتصال مستقیم

```bash
adb devices
adb install app-debug.apk
```

### نصب روش 2: منتقل کردن فایل

1. گوشی را به کامپیوتر متصل کنید
2. فایل `app-debug.apk` را کپی کنید
3. در گوشی: مجوز نصب از منابع نامعلوم را ON کنید
4. روی فایل APK کلیک کنید
5. نصب کنید

## هـ: مشکلات رایج و حل ها

### مشکل: "Gradle sync failed"

**حل:**
```
File → Invalidate Caches / Restart → Clear Cache and Restart
```

### مشکل: "Java version is too old"

**حل:**
```
File → Project Structure → SDK Location
```

Java 11+ را انتخاب کنید.

### مشکل: "SDK Location not found"

**حل:**
1. Installer اندروید استودیو را دوباره اجرا کنید
2. SDK Platform 34 را نصب کنید

### مشکل: Device not found (در اتصال مستقیم)

**حل:**
1. گوشی را قطع کنید
2. دوباره متصل کنید
3. USB Debug را دوباره ON کنید

## و: نسخه Release (اختیاری)

اگر می خواهید نسخه نهایی و بزرگتر ایجاد کنید:

```bash
./gradlew assembleRelease
```

فایل در این مسیر ایجاد می شود:
```
app\build\outputs\apk\release\app-release.apk
```

## ز: اندازه فایل های ایجاد شده

- **Debug APK:** ~35 MB
- **Release APK:** ~15 MB

## س: تعداد خطوط کد

```
Java/Kotlin: ~1500 خط
XML: ~500 خط
کل: ~2000 خط کد
```

## ش: ویژگی های اپلیکیشن

✅ API Level 24+ (Android 7.0+)  
✅ فارسی و انگلیسی  
✅ دسته بندی خودکار  
✅ ارسال ایمیل نامحدود  
✅ بدون اتصال به سرور خارجی  
✅ مصرف حافظه کم  

---

**اگر مشکل دارید:**
1. راهنما را دوباره بخوانید
2. مجوزها را بررسی کنید
3. Gradle Sync را دوباره اجرا کنید
