# ============================================
# اسکریپت ساخت APK برای Windows PowerShell
# ============================================

Write-Host "===========================================" -ForegroundColor Green
Write-Host "    ساخت APK - SMS to Email" -ForegroundColor Green
Write-Host "===========================================" -ForegroundColor Green
Write-Host ""

# بررسی Java
Write-Host "[1/5] بررسی Java..." -ForegroundColor Cyan
$javaPath = (Get-Command java -ErrorAction SilentlyContinue).Source
if ($javaPath) {
    Write-Host "✓ Java پیدا شد: $javaPath" -ForegroundColor Green
} else {
    Write-Host "✗ Java پیدا نشد!" -ForegroundColor Red
    Write-Host "لطفاً Java Development Kit (JDK) 11+ را نصب کنید" -ForegroundColor Yellow
    Write-Host "دانلود از: https://www.oracle.com/java/technologies/downloads/" -ForegroundColor Yellow
    exit 1
}

# بررسی Android SDK
Write-Host ""
Write-Host "[2/5] بررسی Android SDK..." -ForegroundColor Cyan
$androidHome = $env:ANDROID_HOME
if (-not $androidHome) {
    $androidHome = "$env:USERPROFILE\AppData\Local\Android\Sdk"
}

if (Test-Path $androidHome) {
    Write-Host "✓ Android SDK پیدا شد: $androidHome" -ForegroundColor Green
} else {
    Write-Host "✗ Android SDK پیدا نشد!" -ForegroundColor Red
    Write-Host "لطفاً Android Studio را نصب کنید" -ForegroundColor Yellow
    Write-Host "دانلود از: https://developer.android.com/studio" -ForegroundColor Yellow
    exit 1
}

# تنظیم ANDROID_HOME
Write-Host ""
Write-Host "[3/5] تنظیم متغیرهای محیط..." -ForegroundColor Cyan
$env:ANDROID_HOME = $androidHome
Write-Host "✓ ANDROID_HOME تنظیم شد" -ForegroundColor Green

# ساخت APK
Write-Host ""
Write-Host "[4/5] ساخت APK (این ممکن است 5-10 دقیقه طول بکشد)..." -ForegroundColor Cyan
Write-Host ""

try {
    # حذف build قدیمی
    if (Test-Path ".\app\build") {
        Write-Host "حذف build های قدیمی..." -ForegroundColor Yellow
        Remove-Item -Path ".\app\build" -Recurse -Force -ErrorAction SilentlyContinue
    }

    # اجرای Gradle
    & .\gradlew.bat assembleDebug

    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✓ Build موفق!" -ForegroundColor Green
    } else {
        Write-Host ""
        Write-Host "✗ Build ناموفق!" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host ""
    Write-Host "✗ خطا: $_" -ForegroundColor Red
    exit 1
}

# یافتن APK
Write-Host ""
Write-Host "[5/5] یافتن فایل APK..." -ForegroundColor Cyan

$apkPath = ".\app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $apkPath) {
    $apkSize = (Get-Item $apkPath).Length / 1MB
    Write-Host ""
    Write-Host "===========================================" -ForegroundColor Green
    Write-Host "    ✓ APK آماده است!" -ForegroundColor Green
    Write-Host "===========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "فایل: $apkPath" -ForegroundColor Cyan
    Write-Host "اندازه: $([Math]::Round($apkSize, 2)) MB" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "مراحل بعدی:" -ForegroundColor Yellow
    Write-Host "1. گوشی را USB Debugging فعال کنید" -ForegroundColor White
    Write-Host "2. گوشی را به کامپیوتر متصل کنید" -ForegroundColor White
    Write-Host "3. اجرا کنید:" -ForegroundColor White
    Write-Host "   adb install app\build\outputs\apk\debug\app-debug.apk" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "یا فایل APK را به گوشی منتقل کنید و نصب کنید" -ForegroundColor Yellow
} else {
    Write-Host ""
    Write-Host "✗ فایل APK پیدا نشد!" -ForegroundColor Red
    Write-Host "مسیر مورد انتظار: $apkPath" -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "==========================================" -ForegroundColor Green
